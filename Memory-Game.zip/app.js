let symbols = [
  "fa-diamond",
  "fa-diamond",
  "fa-paper-plane-o",
  "fa-paper-plane-o",
  "fa-anchor",
  "fa-anchor",
  "fa-bolt",
  "fa-bolt",
  "fa-cube",
  "fa-cube",
  "fa-leaf",
  "fa-leaf",
  "fa-bicycle",
  "fa-bicycle",
  "fa-bomb",
  "fa-bomb"
];
let open = [];
let matched = 0;
let moveCounter = 0;
let numStars = 3;
let modal = $("#win-modal");
let timer = {
  seconds: 0,
  minutes: 0,
  clearTime: 0
};

//max number of moves for each star

let hard = 15;
let medium = 20;

/* Initalize event listeners */

$(".card").click(onClick);

// Shuffle function from http://stackoverflow.com/a/2450976

function shuffle(array) {
  let currentIndex = array.length,
    temporaryValue,
    randomIndex;

  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}

//Start time with first card clicked

function startTimer() {
  if (timer.seconds === 60) {
    timer.minutes++;
    timer.seconds = 0;
  } else {
    timer.seconds++;
  }
  let formattedSec = "0";
  if (timer.seconds < 10) {
    formattedSec += timer.seconds;
  } else {
    formattedSec = String(timer.seconds);
  }
 let time = String(timer.minutes) + ":" + formattedSec;
  $(".timer").text(time);
}

// Reset and restart timer

function resetTimer() {
  clearInterval(timer.clearTime);
  timer.seconds = 0;
  timer.minutes = 0;
  $(".timer").text("0:00");
  timer.clearTime = setInterval(startTimer, 1000);
}

// Randomizes cards on board

function updateCards() {
  symbols = shuffle(symbols);
  let index = 0;
  $.each($(".card i"), function() {
    $(this).attr("class", "fa " + symbols[index]);
    index++;
  });
}

// show win modal 

function showModal() {
  modal.css("display", "block");
}

// Remove last star from existing 3 stars

function removeStar() {
  $(".fa-star")
    .last()
    .attr("class", "fa fa-star-o");
  numStars--;
  $(".num-stars").text(String(numStars));
}

// Reset stars

function resetStars() {
  $(".fa-star-o").attr("class", "fa fa-star");
  numStars = 3;
  $(".num-stars").text(String(numStars));
}

// Update number of moves and removes star

function updateMoveCounter() {
  $(".moves").text(moveCounter);
  if (moveCounter === hard || moveCounter === medium) {
    removeStar();
  }
}

// Checks validity of card movement

function isValid(card) {
  return !(card.hasClass("open") || card.hasClass("match"));
}

// Returns open cards match(lock the card in open position) or don't match(remove the cards from the list and hide the card's symbol)

function checkMatch() {
  if (open[0].children().attr("class") === open[1].children().attr("class")) {
      let audio = new Audio('http://clockworkchilli.com/assets/demos/memory/sounds/right.ogg');
      audio.play();
      return true;
 } else {
      let audio = new Audio('http://clockworkchilli.com/assets/demos/memory/sounds/wrong.ogg');
      audio.play();
      return false;
  }

}

// Sets currently open cards back to default state

function resetOpen() {
  open.forEach(function(card) {
    card.toggleClass("open");
    card.toggleClass("show");
  });
  open = [];
}

// Sets selected card to the open and shown state

function openCard(card) {
  if (!card.hasClass("open")) {
    card.addClass("open");
    card.addClass("show");
    open.push(card);
  }
}

// Returns win condition with winning sound from http://soundbible.com/1003-Ta-Da.html

function winner() {
  if (matched === 16) {
    let audio = new Audio('sounds/win.mp3');
    audio.play();
    return true;
  } else {
    return false;
  }
}

// If all cards have matched, display a message with the final score
 
function setMatch() {
  open.forEach(function(card) {
    card.addClass("match");
  });
  open = [];
  matched += 2;
  if (winner()) {
    clearInterval(timer.clearTime);
    showModal();
  }
}

// Resets all game state functions

function resetGame() {
  open = [];
  matched = 0;
  moveCounter = 0;
  resetTimer();
  updateMoveCounter();
  $(".card").attr("class", "card");
  updateCards();
  resetStars();
}

//Game logic

function onClick() {
  if(timer.seconds == 0 && timer.minutes == 0){
    resetTimer();
  }
  if (isValid($(this))) {
    if (open.length === 0) {
      openCard($(this)); 
    } else if (open.length === 1) {
      openCard($(this));
      moveCounter++;
      updateMoveCounter();
      if (checkMatch()) {
        setTimeout(setMatch, 300);
      } else {
        setTimeout(resetOpen, 700);
      }
    }
  }
}

// Updates game board on each load
 
 $(updateCards);
